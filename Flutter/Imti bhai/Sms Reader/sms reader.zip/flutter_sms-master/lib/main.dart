import 'package:flutter/widgets.dart';
import './app.dart';

void main() => runApp(new App());
