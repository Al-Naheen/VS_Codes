# Navigation Over Screens

A new Flutter project created with [FlutLab](https://flutlab.io)

### Getting Started: FlutLab - Flutter Online IDE

- Watch Mini crash course "How to use Flutter Widgets" on [FlutLab Youtube Channel](https://www.youtube.com/channel/UC7ZOPQm4JFlvBc9WeynLX_g)
- Discover a marketplace of ready-to-use Flutter projects [FlutLab Widget Bay](https://widgetbay.flutlab.io/)
- Join the discussion and conversation on [FlutLab Facebook Group](https://www.facebook.com/groups/flutlab/)

If you have some questions regarding FlutLab, you can ask on [FlutLab FAQ](https://faq.flutlab.io/)

### Getting Started: Flutter

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
